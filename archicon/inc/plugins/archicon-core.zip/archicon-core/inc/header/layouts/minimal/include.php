<?php

include_once ARCHICON_CORE_INC_PATH . '/header/layouts/minimal/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/header/layouts/minimal/class-archiconcore-minimal-header.php';
include_once ARCHICON_CORE_INC_PATH . '/header/layouts/minimal/dashboard/admin/minimal-header-options.php';
include_once ARCHICON_CORE_INC_PATH . '/header/layouts/minimal/dashboard/meta-box/minimal-header-meta-box.php';
