<?php
// Include logo
archicon_core_get_header_logo_image();
?>
<div class="qodef-header-holder--right">
	<?php
	// Include widget area one
	archicon_core_get_header_widget_area();

	// Include main navigation
	archicon_core_template_part( 'header', 'layouts/switch/templates/navigation' );
	?>
</div>
