<?php

include_once ARCHICON_CORE_INC_PATH . '/header/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/header/class-archiconcore-header.php';
include_once ARCHICON_CORE_INC_PATH . '/header/class-archiconcore-headers.php';
include_once ARCHICON_CORE_INC_PATH . '/header/template-functions.php';
