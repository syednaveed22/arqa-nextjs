<?php

include_once ARCHICON_CORE_INC_PATH . '/title/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/title/class-archiconcore-title.php';
include_once ARCHICON_CORE_INC_PATH . '/title/class-archiconcore-titles.php';
