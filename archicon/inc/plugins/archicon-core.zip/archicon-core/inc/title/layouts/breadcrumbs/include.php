<?php

include_once ARCHICON_CORE_INC_PATH . '/title/layouts/breadcrumbs/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/title/layouts/breadcrumbs/class-archiconcore-breadcrumbs-title.php';
