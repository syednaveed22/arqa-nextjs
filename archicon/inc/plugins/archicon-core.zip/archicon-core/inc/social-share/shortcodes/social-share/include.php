<?php

include_once ARCHICON_CORE_INC_PATH . '/social-share/shortcodes/social-share/class-archiconcore-social-share-shortcode.php';

foreach ( glob( ARCHICON_CORE_INC_PATH . '/social-share/shortcodes/social-share/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
