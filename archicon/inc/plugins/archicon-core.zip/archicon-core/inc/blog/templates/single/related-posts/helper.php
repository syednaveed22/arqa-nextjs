<?php

if ( ! function_exists( 'archicon_core_include_blog_single_related_posts_template' ) ) {
	/**
	 * Function which includes additional module on single posts page
	 */
	function archicon_core_include_blog_single_related_posts_template() {
		if ( is_single() ) {
			include_once ARCHICON_CORE_INC_PATH . '/blog/templates/single/related-posts/templates/related-posts.php';
		}
	}

	add_action( 'archicon_action_after_blog_post_item', 'archicon_core_include_blog_single_related_posts_template', 25 );  // permission 25 is set to define template position
}
