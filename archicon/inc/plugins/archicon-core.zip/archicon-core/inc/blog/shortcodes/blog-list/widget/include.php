<?php

include_once ARCHICON_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-archiconcore-blog-list-widget.php';
include_once ARCHICON_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-archiconcore-simple-blog-list-widget.php';
