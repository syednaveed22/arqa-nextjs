<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/class-archiconcore-woocommerce.php';
