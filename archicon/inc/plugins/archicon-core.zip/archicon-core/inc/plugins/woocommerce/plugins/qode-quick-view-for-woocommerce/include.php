<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/helper.php';
include_once ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/class-archiconcore-qode-quick-view-for-woocommerce.php';
