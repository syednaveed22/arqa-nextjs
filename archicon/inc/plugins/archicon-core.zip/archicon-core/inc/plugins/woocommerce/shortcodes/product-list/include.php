<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-archiconcore-product-list-shortcode.php';

foreach ( glob( ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
