<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/class-archiconcore-qode-wishlist-for-woocommerce.php';
