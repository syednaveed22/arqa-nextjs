<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-archiconcore-twitter-list-shortcode.php';
