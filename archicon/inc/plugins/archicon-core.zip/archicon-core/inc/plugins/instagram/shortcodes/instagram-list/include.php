<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once ARCHICON_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-archiconcore-instagram-list-shortcode.php';
