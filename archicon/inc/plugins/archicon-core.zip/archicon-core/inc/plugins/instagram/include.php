<?php

include_once ARCHICON_CORE_PLUGINS_PATH . '/instagram/helper.php';
