<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once ARCHICON_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once ARCHICON_CORE_PLUGINS_PATH . '/elementor/class-archiconcore-elementor-section-handler.php';
	include_once ARCHICON_CORE_PLUGINS_PATH . '/elementor/class-archiconcore-elementor-container-handler.php';
}
