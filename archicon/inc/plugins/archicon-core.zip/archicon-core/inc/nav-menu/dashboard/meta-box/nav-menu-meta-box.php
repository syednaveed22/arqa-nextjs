<?php

if ( ! function_exists( 'archicon_core_nav_menu_meta_options' ) ) {
	/**
	 * Function that add general options for this module
	 *
	 * @param object $page
	 */
	function archicon_core_nav_menu_meta_options( $page ) {

		if ( $page ) {

			$section = $page->add_section_element(
				array(
					'name'  => 'qodef_nav_menu_section',
					'title' => esc_html__( 'Main Menu', 'archicon-core' ),
				)
			);

			$section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_dropdown_top_position',
					'title'       => esc_html__( 'Dropdown Position', 'archicon-core' ),
					'description' => esc_html__( 'Enter value in percentage of entire header height', 'archicon-core' ),
				)
			);
		}
	}

	add_action( 'archicon_core_action_after_page_header_meta_map', 'archicon_core_nav_menu_meta_options' );
}
