<?php

include_once ARCHICON_CORE_INC_PATH . '/widgets/title/class-archiconcore-title-widget.php';
