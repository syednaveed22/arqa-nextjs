<?php

include_once ARCHICON_CORE_INC_PATH . '/widgets/social-icons-group/class-archiconcore-social-icons-group-widget.php';
