<?php

include_once ARCHICON_CORE_INC_PATH . '/widgets/author-info/class-archiconcore-author-info-widget.php';
