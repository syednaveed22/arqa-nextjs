<?php

include ARCHICON_CORE_INC_PATH . '/widgets/contact-info/class-archiconcore-contact-info-widget.php';
