<?php

include_once ARCHICON_CORE_INC_PATH . '/icons/elegant-icons/class-archiconcore-elegant-icons-pack.php';
