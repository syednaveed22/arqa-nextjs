<?php

include_once ARCHICON_CORE_INC_PATH . '/icons/font-awesome/class-archiconcore-font-awesome-pack.php';
