<?php

include_once ARCHICON_CORE_INC_PATH . '/side-area/widgets/side-area-opener/class-archiconcore-side-area-opener-widget.php';
