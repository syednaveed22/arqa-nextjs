<?php

include_once ARCHICON_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';
