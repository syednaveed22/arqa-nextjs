<?php

if ( ! function_exists( 'archicon_core_include_image_sizes' ) ) {
	/**
	 * Function that includes icons
	 */
	function archicon_core_include_image_sizes() {
		foreach ( glob( ARCHICON_CORE_INC_PATH . '/media/*/include.php' ) as $image_size ) {
			include_once $image_size;
		}
	}

	add_action( 'qode_framework_action_before_images_register', 'archicon_core_include_image_sizes' );
}
