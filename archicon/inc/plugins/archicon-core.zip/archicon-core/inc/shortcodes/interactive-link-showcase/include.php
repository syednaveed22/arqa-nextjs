<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/interactive-link-showcase/class-archiconcore-interactive-link-showcase-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/interactive-link-showcase/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
