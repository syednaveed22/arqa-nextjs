<?php

if ( ! function_exists( 'archicon_core_add_single_image_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function archicon_core_add_single_image_widget( $widgets ) {
		$widgets[] = 'ArchiconCore_Single_Image_Widget';

		return $widgets;
	}

	add_filter( 'archicon_core_filter_register_widgets', 'archicon_core_add_single_image_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class ArchiconCore_Single_Image_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'archicon_core_single_image',
					'exclude'        => array( 'custom_class', 'parallax_item' ),
				)
			);
			if ( $widget_mapped ) {
				$this->set_base( 'archicon_core_single_image' );
				$this->set_name( esc_html__( 'Archicon Single Image', 'archicon-core' ) );
				$this->set_description( esc_html__( 'Add a single image element into widget areas', 'archicon-core' ) );
			}
		}

		public function render( $atts ) {
			echo ArchiconCore_Single_Image_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
