<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/single-image/widget/class-archiconcore-single-image-widget.php';
