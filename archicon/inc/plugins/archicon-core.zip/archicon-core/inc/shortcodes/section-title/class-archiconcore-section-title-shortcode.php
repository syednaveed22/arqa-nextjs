<?php

if ( ! function_exists( 'archicon_core_add_section_title_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function archicon_core_add_section_title_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArchiconCore_Section_Title_Shortcode';

		return $shortcodes;
	}

	add_filter( 'archicon_core_filter_register_shortcodes', 'archicon_core_add_section_title_shortcode' );
}

if ( class_exists( 'ArchiconCore_Shortcode' ) ) {
	class ArchiconCore_Section_Title_Shortcode extends ArchiconCore_Shortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( ARCHICON_CORE_SHORTCODES_URL_PATH . '/section-title' );
			$this->set_base( 'archicon_core_section_title' );
			$this->set_name( esc_html__( 'Section Title', 'archicon-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds section title element', 'archicon-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title',
					'title'      => esc_html__( 'Title', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'tagline',
					'title'      => esc_html__( 'Tagline', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'textarea',
					'name'       => 'text',
					'title'      => esc_html__( 'Text', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'content_alignment',
					'title'      => esc_html__( 'Content Alignment', 'archicon-core' ),
					'options'    => array(
						''        => esc_html__( 'Default', 'archicon-core' ),
						'left'    => esc_html__( 'Left', 'archicon-core' ),
						'center'  => esc_html__( 'Center', 'archicon-core' ),
						'right'   => esc_html__( 'Right', 'archicon-core' ),
						'justify' => esc_html__( 'Justify', 'archicon-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'content_alignment_responsive',
					'title'      => esc_html__( 'Content Alignment Responsive 680', 'archicon-core' ),
					'options'    => array(
						''        => esc_html__( 'Default', 'archicon-core' ),
						'left'    => esc_html__( 'Left', 'archicon-core' ),
						'center'  => esc_html__( 'Center', 'archicon-core' ),
						'right'   => esc_html__( 'Right', 'archicon-core' ),
						'justify' => esc_html__( 'Justify', 'archicon-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'appear',
					'title'      => esc_html__( 'Appear Animation', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'delay',
					'title'      => esc_html__( 'Animation Delay', 'archicon-core' ),
					'dependency' => array(
						'show' => array(
							'appear' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'line_break_positions',
					'title'       => esc_html__( 'Positions of Line Break', 'archicon-core' ),
					'description' => esc_html__( 'Enter the positions of the words after which you would like to create a line break. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a line break, you would enter "1,3,4")', 'archicon-core' ),
					'group'       => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'disable_title_break_words',
					'title'         => esc_html__( 'Disable Title Line Break', 'archicon-core' ),
					'description'   => esc_html__( 'Enabling this option will disable title line breaks for screen size 1024 and lower', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
					'group'         => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'highlight_positions',
					'title'       => esc_html__( 'Highlight Title Words', 'archicon-core' ),
					'description' => esc_html__( 'Enter the positions of the words after which you would like to display as "highlight" text. Separate the positions with commas (e.g. if you would like to "highlight" the first, third, and fourth word, you would enter "1,3,4")', 'archicon-core' ),
					'group'       => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'link',
					'name'        => 'link',
					'title'       => esc_html__( 'Link in Title', 'archicon-core' ),
					'description' => esc_html__( 'Enter your link URL', 'archicon-core' ),
					'group'       => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'target',
					'title'         => esc_html__( 'Link Target', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
					'group'         => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'link_positions',
					'title'       => esc_html__( 'Positions of Link in Title', 'archicon-core' ),
					'description' => esc_html__( 'Enter the position, or start and end position of the words which you would like to include in link. Separate the positions with commas (e.g. if you would like the first and second word to be a link, you would enter "1,2")', 'archicon-core' ),
					'group'       => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'textarea',
					'name'        => 'link_icon',
					'title'       => esc_html__( 'Link Icon SVG', 'archicon-core' ),
					'description' => esc_html__( 'Enter your icon SVG path here. Please remove version and id attributes from your SVG path because of HTML validation', 'archicon-core' ),
					'group'       => esc_html__( 'Title Additional', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'title_tag',
					'title'         => esc_html__( 'Title Tag', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'title_tag' ),
					'default_value' => 'h2',
					'group'         => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size',
					'title'      => esc_html__( 'Title Custom Font Size', 'archicon-core' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'title_font_weight',
					'title'      => esc_html__( 'Title Custom Font Weight', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'font_weight' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height',
					'title'      => esc_html__( 'Title Custom Line Height', 'archicon-core' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing',
					'title'      => esc_html__( 'Title Custom Letter Spacing', 'archicon-core' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			//
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing',
					'title'      => esc_html__( 'Title Custom Word Spacing', 'archicon-core' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'title_text_transform',
					'title'      => esc_html__( 'Title Text Transform', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'text_transform' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'title_color',
					'title'      => esc_html__( 'Title Color', 'archicon-core' ),
					'group'      => esc_html__( 'Title Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_1680',
					'title'      => esc_html__( 'Title Custom Font Size 1680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_1440',
					'title'      => esc_html__( 'Title Custom Font Size 1440', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_1366',
					'title'      => esc_html__( 'Title Custom Font Size 1366', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_1024',
					'title'      => esc_html__( 'Title Custom Font Size 1024', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_768',
					'title'      => esc_html__( 'Title Custom Font Size 768', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_font_size_680',
					'title'      => esc_html__( 'Title Custom Font Size 680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_1680',
					'title'      => esc_html__( 'Title Custom Line Height 1680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_1440',
					'title'      => esc_html__( 'Title Custom Line Height 1440', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_1366',
					'title'      => esc_html__( 'Title Custom Line Height 1366', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_1024',
					'title'      => esc_html__( 'Title Custom Line Height 1024', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_768',
					'title'      => esc_html__( 'Title Custom Line Height 768', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_line_height_680',
					'title'      => esc_html__( 'Title Custom Line Height 680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_1680',
					'title'      => esc_html__( 'Title Custom Letter Spacing 1680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_1440',
					'title'      => esc_html__( 'Title Custom Letter Spacing 1440', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_1366',
					'title'      => esc_html__( 'Title Custom Letter Spacing 1366', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_1024',
					'title'      => esc_html__( 'Title Custom Letter Spacing 1024', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_768',
					'title'      => esc_html__( 'Title Custom Letter Spacing 768', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_letter_spacing_680',
					'title'      => esc_html__( 'Title Custom Letter Spacing 680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			//
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_1680',
					'title'      => esc_html__( 'Title Custom Word Spacing 1680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_1440',
					'title'      => esc_html__( 'Title Custom Word Spacing 1440', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_1366',
					'title'      => esc_html__( 'Title Custom Word Spacing 1366', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_1024',
					'title'      => esc_html__( 'Title Custom Word Spacing 1024', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_768',
					'title'      => esc_html__( 'Title Custom Word Spacing 768', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_word_spacing_680',
					'title'      => esc_html__( 'Title Custom Word Spacing 680', 'archicon-core' ),
					'group'      => esc_html__( 'Title Responsive Style', 'archicon-core' ),
				)
			);
			//
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'highlight_color',
					'title'      => esc_html__( 'Highlight Color', 'archicon-core' ),
					'group'      => esc_html__( 'Title Highlight Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'highlight_font_weight',
					'title'      => esc_html__( 'Highlight Font Weight', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'font_weight' ),
					'group'      => esc_html__( 'Title Highlight Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'link_color',
					'title'      => esc_html__( 'Link Color', 'archicon-core' ),
					'group'      => esc_html__( 'Title Link Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'link_hover_color',
					'title'      => esc_html__( 'Link Hover Color', 'archicon-core' ),
					'group'      => esc_html__( 'Title Link Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'link_font_weight',
					'title'      => esc_html__( 'Link Font Weight', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'font_weight' ),
					'group'      => esc_html__( 'Title Link Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'link_text_decoration',
					'title'      => esc_html__( 'Link Text Decoration', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'text_decoration' ),
					'group'      => esc_html__( 'Title Link Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'tagline_tag',
					'title'         => esc_html__( 'Tagline Tag', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'title_tag' ),
					'default_value' => 'p',
					'group'         => esc_html__( 'Tagline Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'tagline_text_transform',
					'title'      => esc_html__( 'Tagline Text Transform', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'text_transform' ),
					'group'      => esc_html__( 'Tagline Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'tagline_color',
					'title'      => esc_html__( 'Tagline Color', 'archicon-core' ),
					'group'      => esc_html__( 'Tagline Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'tagline_margin_bottom',
					'title'      => esc_html__( 'Tagline Margin Top', 'archicon-core' ),
					'group'      => esc_html__( 'Tagline Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'text_tag',
					'title'         => esc_html__( 'Text Tag', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'title_tag' ),
					'default_value' => 'h5',
					'group'         => esc_html__( 'Text Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'text_color',
					'title'      => esc_html__( 'Text Color', 'archicon-core' ),
					'group'      => esc_html__( 'Text Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'text_margin_top',
					'title'      => esc_html__( 'Text Margin Top', 'archicon-core' ),
					'group'      => esc_html__( 'Text Style', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'button_text',
					'title'      => esc_html__( 'Button Text', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'button_link',
					'title'      => esc_html__( 'Button Link', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'button_target',
					'title'         => esc_html__( 'Button Target', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'button_margin_top',
					'title'      => esc_html__( 'Button Margin Top', 'archicon-core' ),
					'group'      => esc_html__( 'Button Style', 'archicon-core' ),
				)
			);
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes']     = $this->get_holder_classes( $atts );
			$atts['title']              = $this->get_modified_title( $atts );
			$atts['title_styles']       = $this->get_title_styles( $atts );
			$atts['title_inner_styles'] = $this->get_title_inner_styles( $atts );
			$atts['title_icon_styles']  = $this->get_title_icon_styles( $atts );
			$atts['tagline_styles']     = $this->get_tagline_styles( $atts );
			$atts['text_styles']        = $this->get_text_styles( $atts );
			$atts['animation_data']     = $this->get_animation_data( $atts );
			$atts['button_styles']      = $this->get_button_styles( $atts );

			return archicon_core_get_template_part( 'shortcodes/section-title', 'templates/section-title', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-section-title';
			$holder_classes[] = ! empty( $atts['content_alignment'] ) ? 'qodef-alignment--' . $atts['content_alignment'] : 'qodef-alignment--left';
			$holder_classes[] = ! empty( $atts['content_alignment_responsive'] ) ? 'qodef-alignment-responsive--' . $atts['content_alignment_responsive'] : '';
			$holder_classes[] = 'yes' === $atts['disable_title_break_words'] ? 'qodef-title-break--disabled' : '';
			$holder_classes[] = ! empty( $atts['appear'] ) && ( 'yes' === $atts['appear'] ) ? 'qodef-has-appear' : '';

			return implode( ' ', $holder_classes );
		}

		private function get_modified_title( $atts ) {
			$text = $atts['title'];

			if ( ! empty( $text ) ) {
				$split_text = explode( ' ', $text );

				if ( ! empty( $atts['highlight_positions'] ) ) {
					$highlight_positions = explode( ',', str_replace( ' ', '', $atts['highlight_positions'] ) );

					foreach ( $highlight_positions as $position ) {
						$position = intval( $position );
						if ( isset( $split_text[$position - 1] ) && ! empty( $split_text[$position - 1] ) ) {
							$split_text[$position - 1] = '<span class="qodef-m-highlight-text" ' . qode_framework_get_inline_style( $this->get_highlight_styles( $atts ) ) . '><span class="qodef--original">' . $split_text[$position - 1] . '</span><span class="qodef--fake" ' . qode_framework_get_inline_style( $this->get_highlight_color( $atts ) ) . '>' . $split_text[$position - 1] . '</span></span>';
						}
					}
				}

				if ( ! empty( $atts['link_positions'] ) && ! empty( $atts['link'] ) ) {
					$link_positions = explode( ',', str_replace( ' ', '', $atts['link_positions'] ) );
					$link_icon      = ! empty( $atts['link_icon'] ) ? qode_framework_wp_kses_html( 'svg', $atts['link_icon'] ) : '';

					if ( count( $link_positions ) === 2 ) {
						$begin = intval( $link_positions[0] );
						$end   = intval( $link_positions[1] );
						if ( ! empty( $split_text[$begin - 1] ) && ! empty( $split_text [$end - 1] ) ) {
							$split_text[$begin - 1] = '<a class="qodef-m-link" href="' . esc_url( $atts['link'] ) . '" target="' . esc_attr( $atts['target'] ) . '" ' . qode_framework_get_inline_style( $this->get_link_styles( $atts ) ) . '>' . $split_text[$begin - 1];
							$split_text[$end - 1]   = $split_text[$end - 1] . $link_icon . '</a>';
						}
					} else {
						foreach ( $link_positions as $position ) {
							$position = intval( $position );

							if ( isset( $split_text[$position - 1] ) && ! empty( $split_text[$position - 1] ) ) {
								$split_text[$position - 1] = '<a class="qodef-m-link" href="' . esc_url( $atts['link'] ) . '" target="' . esc_attr( $atts['target'] ) . '" ' . qode_framework_get_inline_style( $this->get_link_styles( $atts ) ) . '>' . $split_text[$position - 1] . $link_icon . '</a>';
							}
						}
					}
				}

				if ( ! empty( $atts['line_break_positions'] ) ) {
					$line_break_positions = explode( ',', str_replace( ' ', '', $atts['line_break_positions'] ) );

					foreach ( $line_break_positions as $position ) {
						$position = intval( $position );
						if ( isset( $split_text[$position - 1] ) && ! empty( $split_text[$position - 1] ) ) {
							$split_text[$position - 1] = $split_text[$position - 1] . '<br />';
						}
					}
				}

				$text = implode( ' ', $split_text );
			}

			return $text;
		}

		private function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}

			if ( ! empty( $atts['title_font_weight'] ) ) {
				$styles[] = 'font-weight: ' . $atts['title_font_weight'];
			}

			if ( ! empty( $atts['title_text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['title_text_transform'];
			}

			return $styles;
		}

		private function get_title_inner_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['title_font_size'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size'], true ) ) {
					$styles[] = '--qodef-st-custom-fs: ' . $atts['title_font_size'];
				} else {
					$styles[] = '--qodef-st-custom-fs: ' . intval( $atts['title_font_size'] ) . 'px';
				}

				if ( empty( $atts['title_line_height'] ) ) {
					$styles[] = '--qodef-st-custom-lh: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_1680'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_1680'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-1680: ' . $atts['title_font_size_1680'];
				} else {
					$styles[] = '--qodef-st-custom-fs-1680: ' . intval( $atts['title_font_size_1680'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_1680'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1680: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_1440'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_1440'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-1440: ' . $atts['title_font_size_1440'];
				} else {
					$styles[] = '--qodef-st-custom-fs-1440: ' . intval( $atts['title_font_size_1440'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_1440'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1440: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_1366'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_1366'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-1366: ' . $atts['title_font_size_1366'];
				} else {
					$styles[] = '--qodef-st-custom-fs-1366: ' . intval( $atts['title_font_size_1366'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_1366'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1366: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_1024'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_1024'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-1024: ' . $atts['title_font_size_1024'];
				} else {
					$styles[] = '--qodef-st-custom-fs-1024: ' . intval( $atts['title_font_size_1024'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_1024'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1024: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_768'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_768'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-768: ' . $atts['title_font_size_768'];
				} else {
					$styles[] = '--qodef-st-custom-fs-768: ' . intval( $atts['title_font_size_768'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_768'] ) ) {
					$styles[] = '--qodef-st-custom-lh-768: 1';
				}
			}

			if ( ! empty( $atts['title_font_size_680'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_font_size_680'], true ) ) {
					$styles[] = '--qodef-st-custom-fs-680: ' . $atts['title_font_size_680'];
				} else {
					$styles[] = '--qodef-st-custom-fs-680: ' . intval( $atts['title_font_size_680'] ) . 'px';
				}

				if ( empty( $atts['title_line_height_680'] ) ) {
					$styles[] = '--qodef-st-custom-lh-680: 1';
				}
			}

			if ( ! empty( $atts['title_line_height'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height'] ) ) {
					$styles[] = '--qodef-st-custom-lh: ' . $atts['title_line_height'];
				} else {
					$styles[] = '--qodef-st-custom-lh: ' . intval( $atts['title_line_height'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_1680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_1680'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1680: ' . $atts['title_line_height_1680'];
				} else {
					$styles[] = '--qodef-st-custom-lh-1680: ' . intval( $atts['title_line_height_1680'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_1440'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_1440'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1440: ' . $atts['title_line_height_1440'];
				} else {
					$styles[] = '--qodef-st-custom-lh-1440: ' . intval( $atts['title_line_height_1440'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_1366'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_1366'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1366: ' . $atts['title_line_height_1366'];
				} else {
					$styles[] = '--qodef-st-custom-lh-1366: ' . intval( $atts['title_line_height_1366'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_1024'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_1024'] ) ) {
					$styles[] = '--qodef-st-custom-lh-1024: ' . $atts['title_line_height_1024'];
				} else {
					$styles[] = '--qodef-st-custom-lh-1024: ' . intval( $atts['title_line_height_1024'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_768'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_768'] ) ) {
					$styles[] = '--qodef-st-custom-lh-768: ' . $atts['title_line_height_768'];
				} else {
					$styles[] = '--qodef-st-custom-lh-768: ' . intval( $atts['title_line_height_768'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_line_height_680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_line_height_680'] ) ) {
					$styles[] = '--qodef-st-custom-lh-680: ' . $atts['title_line_height_680'];
				} else {
					$styles[] = '--qodef-st-custom-lh-680: ' . intval( $atts['title_line_height_680'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing'] ) ) {
					$styles[] = '--qodef-st-custom-ls: ' . $atts['title_letter_spacing'];
				} else {
					$styles[] = '--qodef-st-custom-ls: ' . intval( $atts['title_letter_spacing'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_1680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_1680'] ) ) {
					$styles[] = '--qodef-st-custom-ls-1680: ' . $atts['title_letter_spacing_1680'];
				} else {
					$styles[] = '--qodef-st-custom-ls-1680: ' . intval( $atts['title_letter_spacing_1680'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_1440'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_1440'] ) ) {
					$styles[] = '--qodef-st-custom-ls-1440: ' . $atts['title_letter_spacing_1440'];
				} else {
					$styles[] = '--qodef-st-custom-ls-1440: ' . intval( $atts['title_letter_spacing_1440'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_1366'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_1366'] ) ) {
					$styles[] = '--qodef-st-custom-ls-1366: ' . $atts['title_letter_spacing_1366'];
				} else {
					$styles[] = '--qodef-st-custom-ls-1366: ' . intval( $atts['title_letter_spacing_1366'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_1024'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_1024'] ) ) {
					$styles[] = '--qodef-st-custom-ls-1024: ' . $atts['title_letter_spacing_1024'];
				} else {
					$styles[] = '--qodef-st-custom-ls-1024: ' . intval( $atts['title_letter_spacing_1024'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_768'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_768'] ) ) {
					$styles[] = '--qodef-st-custom-ls-768: ' . $atts['title_letter_spacing_768'];
				} else {
					$styles[] = '--qodef-st-custom-ls-768: ' . intval( $atts['title_letter_spacing_768'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_letter_spacing_680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_letter_spacing_680'] ) ) {
					$styles[] = '--qodef-st-custom-ls-680: ' . $atts['title_letter_spacing_680'];
				} else {
					$styles[] = '--qodef-st-custom-ls-680: ' . intval( $atts['title_letter_spacing_680'] ) . 'px';
				}
			}

			//

			if ( ! empty( $atts['title_word_spacing'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing'] ) ) {
					$styles[] = '--qodef-st-custom-ws: ' . $atts['title_word_spacing'];
				} else {
					$styles[] = '--qodef-st-custom-ws: ' . intval( $atts['title_word_spacing'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_1680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_1680'] ) ) {
					$styles[] = '--qodef-st-custom-ws-1680: ' . $atts['title_word_spacing_1680'];
				} else {
					$styles[] = '--qodef-st-custom-ws-1680: ' . intval( $atts['title_word_spacing_1680'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_1440'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_1440'] ) ) {
					$styles[] = '--qodef-st-custom-ws-1440: ' . $atts['title_word_spacing_1440'];
				} else {
					$styles[] = '--qodef-st-custom-ws-1440: ' . intval( $atts['title_word_spacing_1440'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_1366'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_1366'] ) ) {
					$styles[] = '--qodef-st-custom-ws-1366: ' . $atts['title_word_spacing_1366'];
				} else {
					$styles[] = '--qodef-st-custom-ws-1366: ' . intval( $atts['title_word_spacing_1366'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_1024'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_1024'] ) ) {
					$styles[] = '--qodef-st-custom-ws-1024: ' . $atts['title_word_spacing_1024'];
				} else {
					$styles[] = '--qodef-st-custom-ws-1024: ' . intval( $atts['title_word_spacing_1024'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_768'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_768'] ) ) {
					$styles[] = '--qodef-st-custom-ws-768: ' . $atts['title_word_spacing_768'];
				} else {
					$styles[] = '--qodef-st-custom-ws-768: ' . intval( $atts['title_word_spacing_768'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_word_spacing_680'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['title_word_spacing_680'] ) ) {
					$styles[] = '--qodef-st-custom-ws-680: ' . $atts['title_word_spacing_680'];
				} else {
					$styles[] = '--qodef-st-custom-ws-680: ' . intval( $atts['title_word_spacing_680'] ) . 'px';
				}
			}

			return $styles;
		}

		private function get_highlight_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['highlight_font_weight'] ) ) {
				$styles[] = 'font-weight: ' . $atts['highlight_font_weight'];
			}

			return $styles;
		}

		private function get_highlight_color( $atts ) {
			$styles = array();

			if ( ! empty( $atts['highlight_color'] ) ) {
				$styles[] = 'color: ' . $atts['highlight_color'];
			}

			return $styles;
		}

		private function get_animation_data( $atts ) {
			$data = array();

			if ( ! empty( $atts['delay'] ) ) {
				$data[] = $atts['delay'];
			}

			return $data;
		}

		private function get_link_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['link_color'] ) ) {
				$styles[] = '--qodef-st-link-color: ' . $atts['link_color'];
			}

			if ( ! empty( $atts['link_hover_color'] ) ) {
				$styles[] = '--qodef-st-link-hover-color: ' . $atts['link_hover_color'];
			}

			if ( ! empty( $atts['link_font_weight'] ) ) {
				$styles[] = 'font-weight: ' . $atts['link_font_weight'];
			}

			if ( ! empty( $atts['link_text_decoration'] ) ) {
				$styles[] = 'text-decoration: ' . $atts['link_text_decoration'];
			}

			return $styles;
		}

		private function get_title_icon_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['title_icon_height'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_icon_height'] ) ) {
					$styles[] = 'height: ' . $atts['title_icon_height'];
				} else {
					$styles[] = 'height: ' . intval( $atts['title_icon_height'] ) . 'px';
				}
			}

			if ( ! empty( $atts['title_icon_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_icon_color'];
			}

			return $styles;
		}

		private function get_tagline_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['tagline_margin_bottom'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['tagline_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['tagline_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['tagline_margin_bottom'] ) . 'px';
				}
			}

			if ( ! empty( $atts['tagline_color'] ) ) {
				$styles[] = 'color: ' . $atts['tagline_color'];
			}

			if ( ! empty( $atts['tagline_text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['tagline_text_transform'];
			}

			return $styles;
		}

		private function get_text_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['text_margin_top'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['text_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['text_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['text_margin_top'] ) . 'px';
				}
			}

			if ( ! empty( $atts['text_color'] ) ) {
				$styles[] = 'color: ' . $atts['text_color'];
			}

			return $styles;
		}

		private function get_button_styles( $atts ) {
			$styles = array();

			if ( '' !== $atts['button_margin_top'] ) {
				if ( qode_framework_string_ends_with_space_units( $atts['button_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['button_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['button_margin_top'] ) . 'px';
				}
			}

			return $styles;
		}
	}
}
