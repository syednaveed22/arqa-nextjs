<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/section-title/class-archiconcore-section-title-shortcode.php';
