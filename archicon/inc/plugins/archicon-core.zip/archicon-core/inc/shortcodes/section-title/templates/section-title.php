<div <?php qode_framework_class_attribute( $holder_classes ); ?>  <?php qode_framework_inline_attr( $animation_data, 'data-animation' ); ?>>
	<?php archicon_core_template_part( 'shortcodes/section-title', 'templates/parts/tagline', '', $params ); ?>
	<?php archicon_core_template_part( 'shortcodes/section-title', 'templates/parts/title', '', $params ); ?>
	<?php archicon_core_template_part( 'shortcodes/section-title', 'templates/parts/text', '', $params ); ?>
	<?php archicon_core_template_part( 'shortcodes/section-title', 'templates/parts/button', '', $params ); ?>
</div>
