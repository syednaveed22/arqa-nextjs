<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/button/widget/class-archiconcore-button-widget.php';
