<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/button/class-archiconcore-button-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/button/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
