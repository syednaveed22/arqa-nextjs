<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/custom-font/class-archiconcore-custom-font-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/custom-font/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
