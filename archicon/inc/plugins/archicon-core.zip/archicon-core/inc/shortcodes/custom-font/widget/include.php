<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/custom-font/widget/class-archiconcore-custom-font-widget.php';
