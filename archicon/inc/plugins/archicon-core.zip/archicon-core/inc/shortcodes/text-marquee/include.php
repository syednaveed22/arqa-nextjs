<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/text-marquee/class-archiconcore-text-marquee-shortcode.php';

foreach ( glob( ARCHICON_CORE_INC_PATH . '/shortcodes/text-marquee/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
