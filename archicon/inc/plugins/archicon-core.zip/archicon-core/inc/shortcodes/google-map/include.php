<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/google-map/class-archiconcore-google-map-shortcode.php';
