<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/accordion/class-archiconcore-accordion-shortcode.php';
include_once ARCHICON_CORE_SHORTCODES_PATH . '/accordion/class-archiconcore-accordion-child-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/accordion/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
