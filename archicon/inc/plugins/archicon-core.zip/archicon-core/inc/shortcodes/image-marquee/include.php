<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/image-marquee/class-archiconcore-image-marquee-shortcode.php';

foreach ( glob( ARCHICON_CORE_INC_PATH . '/shortcodes/image-marquee/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
