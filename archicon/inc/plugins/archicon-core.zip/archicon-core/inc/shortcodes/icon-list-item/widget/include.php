<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/icon-list-item/widget/class-archiconcore-icon-list-item-widget.php';
