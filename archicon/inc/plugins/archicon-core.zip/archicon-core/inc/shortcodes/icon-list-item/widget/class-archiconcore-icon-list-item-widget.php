<?php

if ( ! function_exists( 'archicon_core_add_icon_list_item_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function archicon_core_add_icon_list_item_widget( $widgets ) {
		$widgets[] = 'ArchiconCore_Icon_List_Item_Widget';

		return $widgets;
	}

	add_filter( 'archicon_core_filter_register_widgets', 'archicon_core_add_icon_list_item_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class ArchiconCore_Icon_List_Item_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'archicon_core_icon_list_item',
					'exclude'        => array( 'icon_type', 'custom_icon' ),
				)
			);
			if ( $widget_mapped ) {
				$this->set_base( 'archicon_core_icon_list_item' );
				$this->set_name( esc_html__( 'Archicon Icon List Item', 'archicon-core' ) );
				$this->set_description( esc_html__( 'Add a icon list item element into widget areas', 'archicon-core' ) );
			}
		}

		public function render( $atts ) {
			echo ArchiconCore_Icon_List_Item_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
