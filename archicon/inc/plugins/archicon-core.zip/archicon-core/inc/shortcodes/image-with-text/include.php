<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/image-with-text/class-archiconcore-image-with-text-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/image-with-text/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
