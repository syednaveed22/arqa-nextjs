<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/icon/widget/class-archiconcore-icon-widget.php';
