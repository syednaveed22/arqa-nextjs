<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/icon/class-archiconcore-icon-shortcode.php';
