<?php

if ( ! function_exists( 'archicon_core_add_workflow_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function archicon_core_add_workflow_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArchiconCore_Timeline';

		return $shortcodes;
	}

	add_filter( 'archicon_core_filter_register_shortcodes', 'archicon_core_add_workflow_shortcode' );
}

if ( class_exists( 'ArchiconCore_Shortcode' ) ) {
	class ArchiconCore_Timeline extends ArchiconCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'archicon_core_filter_timeline_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'archicon_core_filter_timeline_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( ARCHICON_CORE_SHORTCODES_URL_PATH . '/timeline' );
			$this->set_base( 'archicon_core_timeline' );
			$this->set_name( esc_html__( 'Alternating Timeline Showcase', 'archicon-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds timeline showcase element', 'archicon-core' ) );

			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'archicon-core' ),
				)
			);

			$layouts_type = apply_filters( 'archicon_core_filter_timeline_layouts_type', array() );
			$options_map  = archicon_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'archicon-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'repeater',
					'name'       => 'children',
					'title'      => esc_html__( 'Items', 'archicon-core' ),
					'items'      => array(
						array(
							'field_type' => 'image',
							'name'       => 'image',
							'title'      => esc_html__( 'Image', 'archicon-core' ),
						),
						array(
							'field_type'    => 'text',
							'name'          => 'title',
							'title'         => esc_html__( 'Title', 'archicon-core' ),
							'default_value' => esc_html__( 'Example Title', 'archicon-core' ),
						),
						array(
							'field_type' => 'textarea',
							'name'       => 'text',
							'title'      => esc_html__( 'Text', 'archicon-core' ),
						),
						array(
							'field_type' => 'text',
							'name'       => 'link',
							'title'      => esc_html__( 'Link', 'archicon-core' ),
						),
						array(
							'field_type'    => 'select',
							'name'          => 'target',
							'title'         => esc_html__( 'Target', 'archicon-core' ),
							'options'       => archicon_core_get_select_type_options_pool( 'link_target' ),
							'default_value' => '_self',
						),
					),
				)
			);

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'image_proportion',
					'default_value' => 'full',
					'title'         => esc_html__( 'Image Proportions', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'list_image_dimension', false, array( 'custom' ) ),
					'group'         => esc_html__( 'Content Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'title_tag',
					'title'         => esc_html__( 'Title Tag', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'title_tag', false ),
					'default_value' => 'h4',
					'group'         => esc_html__( 'Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'title_color',
					'title'      => esc_html__( 'Title Color', 'archicon-core' ),
					'group'      => esc_html__( 'Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title_margin_bottom',
					'title'      => esc_html__( 'Title Margin Bottom', 'archicon-core' ),
					'group'      => esc_html__( 'Spacing Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'text_color',
					'title'      => esc_html__( 'Text Color', 'archicon-core' ),
					'group'      => esc_html__( 'Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'line_color',
					'title'      => esc_html__( 'Line Color', 'archicon-core' ),
					'group'      => esc_html__( 'Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'color',
					'name'       => 'point_color',
					'title'      => esc_html__( 'Point Color', 'archicon-core' ),
					'group'      => esc_html__( 'Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'space_between_items',
					'title'      => esc_html__( 'Space Between Items', 'archicon-core' ),
					'group'      => esc_html__( 'Spacing Style', 'archicon-core' ),
				)
			);

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns',
					'title'         => esc_html__( 'Number of Columns', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number', true ),
					'default_value' => '4',
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_responsive',
					'title'         => esc_html__( 'Columns Responsive', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_responsive' ),
					'default_value' => 'predefined',
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_1440',
					'title'         => esc_html__( 'Number of Columns 1367px - 1440px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '3',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_1366',
					'title'         => esc_html__( 'Number of Columns 1025px - 1366px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '3',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_1024',
					'title'         => esc_html__( 'Number of Columns 769px - 1024px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '2',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_768',
					'title'         => esc_html__( 'Number of Columns 681px - 768px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '2',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_680',
					'title'         => esc_html__( 'Number of Columns 481px - 680px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '1',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns_480',
					'title'         => esc_html__( 'Number of Columns 0 - 480px', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'columns_number' ),
					'default_value' => '1',
					'dependency'    => array(
						'show' => array(
							'columns_responsive' => array(
								'values'        => 'custom',
								'default_value' => '4',
							),
						),
					),
					'group'         => esc_html__( 'Columns', 'archicon-core' ),
				)
			);

			$this->map_extra_options();
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['type'] = apply_filters( 'archicon_core_filter_timeline_layouts_type', array() )[ $atts['layout'] ];

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['holder_data']    = json_encode( $this->get_holder_data( $atts ) );
			$atts['items']          = $this->parse_repeater_items( $atts['children'] );
			$atts['this_shortcode'] = $this;

			return archicon_core_get_template_part( 'shortcodes/timeline', 'templates/timeline', $atts['type'], $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-timeline';
			$holder_classes[] = ! empty( $atts['type'] ) ? 'qodef-timeline--' . $atts['type'] : '';
			$holder_classes[] = ( 'horizontal' === $atts['type'] ) ? 'qodef-layout--columns' : '';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-timeline-layout--' . $atts['layout'] : '';

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();

			$item_classes[] = 'qodef-e-item';
			$item_classes[] = ( 'horizontal' === $atts['type'] ) ? 'qodef-grid-item' : '';

			return implode( ' ', $item_classes );
		}

		public function get_item_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['space_between_items'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['space_between_items'] ) ) {
					$styles[] = 'padding: 0 calc(' . $atts['space_between_items'] . '/2)';
				} else {
					$styles[] = 'padding: 0 calc(' . intval( $atts['space_between_items'] ) . 'px/2)';
				}
			}

			return $styles;
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}

			if ( ! empty( $atts['title_margin_bottom'] ) ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['title_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['title_margin_bottom'] ) . 'px';
				}
			}

			return $styles;
		}

		public function get_text_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_color'] ) ) {
				$styles[] = 'color: ' . $atts['text_color'];
			}

			return $styles;
		}

		public function get_line_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['line_color'] ) ) {
				$styles[] = 'background-color: ' . $atts['line_color'];
			}

			return $styles;
		}

		public function get_point_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['point_color'] ) ) {
				$styles[] = 'background-color: ' . $atts['point_color'];
			}

			return $styles;
		}

		private function get_holder_data( $atts ) {
			$data = array();

			$data['colNum'] = ! empty( $atts['columns'] ) ? $atts['columns'] : '4';

			if ( ! empty( $atts['columns_responsive'] ) && 'custom' === $atts['columns_responsive'] ) {
				$data['colNum1440'] = ! empty( $atts['columns_1440'] ) ? $atts['columns_1440'] : $atts['columns'];
				$data['colNum1366'] = ! empty( $atts['columns_1366'] ) ? $atts['columns_1366'] : $atts['columns'];
				$data['colNum1024'] = ! empty( $atts['columns_1024'] ) ? $atts['columns_1024'] : $atts['columns'];
				$data['colNum768']  = ! empty( $atts['columns_768'] ) ? $atts['columns_768'] : $atts['columns'];
				$data['colNum680']  = ! empty( $atts['columns_680'] ) ? $atts['columns_680'] : $atts['columns'];
				$data['colNum480']  = ! empty( $atts['columns_480'] ) ? $atts['columns_480'] : $atts['columns'];
			} else {
				$data['colNum1440'] = $data['colNum'];
				$data['colNum1366'] = $data['colNum'];
				$data['colNum1024'] = $data['colNum'];
				$data['colNum768']  = $data['colNum'];

				if ( 6 <= $data['colNum'] ) {
					$data['colNum1440'] = '5';
				}
				if ( 5 <= $data['colNum'] ) {
					$data['colNum1366'] = '4';
				}
				if ( 4 <= $data['colNum'] ) {
					$data['colNum1024'] = '3';
				}
				if ( 3 <= $data['colNum'] ) {
					$data['colNum768'] = '2';
				}
				$data['colNum680'] = '1';
				$data['colNum480'] = '1';
			}

			return $data;
		}
	}
}
