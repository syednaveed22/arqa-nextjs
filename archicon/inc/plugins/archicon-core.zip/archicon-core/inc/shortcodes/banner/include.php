<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/banner/class-archiconcore-banner-shortcode.php';

foreach ( glob( ARCHICON_CORE_INC_PATH . '/shortcodes/banner/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
