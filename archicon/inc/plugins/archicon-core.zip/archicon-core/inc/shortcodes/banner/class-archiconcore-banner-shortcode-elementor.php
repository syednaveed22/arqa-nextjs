<?php

class ArchiconCore_Banner_Shortcode_Elementor extends ArchiconCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'archicon_core_banner' );

		parent::__construct( $data, $args );
	}
}

archicon_core_register_new_elementor_widget( new ArchiconCore_Banner_Shortcode_Elementor() );
