<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/dropcaps/class-archiconcore-dropcaps-shortcode.php';
