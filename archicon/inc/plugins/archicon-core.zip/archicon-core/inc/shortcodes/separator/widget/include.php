<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/separator/widget/class-archiconcore-separator-widget.php';
include_once ARCHICON_CORE_SHORTCODES_PATH . '/separator/widget/class-archiconcore-simple-separator-widget.php';
