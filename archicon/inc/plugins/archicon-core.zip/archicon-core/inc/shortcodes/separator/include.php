<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/separator/class-archiconcore-separator-shortcode.php';
