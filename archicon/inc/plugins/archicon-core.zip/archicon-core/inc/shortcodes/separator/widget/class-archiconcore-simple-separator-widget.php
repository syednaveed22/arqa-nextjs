<?php

if ( ! function_exists( 'archicon_core_add_simple_separator_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function archicon_core_add_simple_separator_widget( $widgets ) {
		$widgets[] = 'ArchiconCore_Simple_Separator_Widget';

		return $widgets;
	}

	add_filter( 'archicon_core_filter_register_widgets', 'archicon_core_add_simple_separator_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class ArchiconCore_Simple_Separator_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'archicon_core_separator',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'archicon_core_simple_separator' );
				$this->set_name( esc_html__( 'Archicon Simple Separator', 'archicon-core' ) );
				$this->set_description( esc_html__( 'Add a simple separator element into widget areas', 'archicon-core' ) );
			}
		}

		public function render( $atts ) {
			$simple_separator_atts = $this->get_simple_separator_styles( $atts );

			$separator_params = array(
				'is_simple_widget_element' => 'yes',
				'width'                    => $simple_separator_atts['width'],
				'margin_left'              => $simple_separator_atts['margin_left'],
				'margin_right'             => $simple_separator_atts['margin_right'],
			);

			echo ArchiconCore_Separator_Shortcode::call_shortcode( array_merge( $atts, $separator_params ) ); // XSS OK
		}

		private function get_simple_separator_styles( $atts ) {
			$default_sidebar_gutter = archicon_core_get_post_value_through_levels( 'qodef_page_sidebar_grid_gutter' );
			$woo_sidebar_gutter     = archicon_core_get_post_value_through_levels( 'qodef_woo_product_list_sidebar_grid_gutter' );

			$gutter_size = qode_framework_is_installed( 'woocommerce' ) && archicon_is_woo_page( 'any' ) && ! empty( $woo_sidebar_gutter ) ? $woo_sidebar_gutter : $default_sidebar_gutter;

			switch ( $gutter_size ) {
				case 'enormous':
					$gutter_value = 70;
					break;
				case 'huge':
					$gutter_value = 40;
					break;
				case 'extra-large':
					$gutter_value = 30;
					break;
				case 'large':
					$gutter_value = 25;
					break;
				case 'medium':
					$gutter_value = 20;
					break;
				case 'small':
					$gutter_value = 10;
					break;
				case 'tiny':
					$gutter_value = 5;
					break;
				case 'no':
					$gutter_value = 0;
					break;
				default:
					$gutter_value = 15;
					break;
			}

			if ( ! empty( $atts['margin_left'] ) ) {
				$atts['margin_left'] = - ( $gutter_value + (int) $atts['margin_left'] );
				$atts['width']       = 'calc(100% - ' . $atts['margin_left'] . 'px)';
			}

			if ( ! empty( $atts['margin_right'] ) ) {
				$atts['margin_right'] = - ( $gutter_value + (int) $atts['margin_right'] );
				$atts['width']        = 'calc(100% - ' . $atts['margin_right'] . 'px)';
			}

			return $atts;

		}
	}
}
