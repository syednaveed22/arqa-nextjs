<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/single-svg/class-archiconcore-single-svg-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/single-svg/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
