<?php

if ( ! function_exists( 'archicon_core_add_single_svg_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function archicon_core_add_single_svg_shortcode( $shortcodes ) {
		$shortcodes[] = 'ArchiconCore_Single_SVG_Shortcode';

		return $shortcodes;
	}

	add_filter( 'archicon_core_filter_register_shortcodes', 'archicon_core_add_single_svg_shortcode' );
}

if ( class_exists( 'ArchiconCore_Shortcode' ) ) {
	class ArchiconCore_Single_SVG_Shortcode extends ArchiconCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'archicon_core_filter_single_svg_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'archicon_core_filter_single_svg_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( ARCHICON_CORE_SHORTCODES_URL_PATH . '/single-svg' );
			$this->set_base( 'archicon_core_single_svg' );
			$this->set_name( esc_html__( 'Single SVG', 'archicon-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds SVG element', 'archicon-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'archicon-core' ),
				)
			);

			$options_map = archicon_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'archicon-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'textarea',
					'name'        => 'svg_code',
					'title'       => esc_html__( 'SVG Code', 'archicon-core' ),
					'description' => esc_html__( 'Enter your icon SVG path here. Please remove version and id attributes from your SVG path because of HTML validation', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'link',
					'title'      => esc_html__( 'Custom Link', 'archicon-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'target',
					'title'         => esc_html__( 'Custom Link Target', 'archicon-core' ),
					'options'       => archicon_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'appear',
					'title'      => esc_html__( 'Appear Animation', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'custom_parallax',
					'title'      => esc_html__( 'Custom Parallax Effect', 'archicon-core' ),
					'options'    => archicon_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'parallax_amount',
					'title'      => esc_html__( 'Parallax Amount', 'archicon-core' ),
					'description' => esc_html__( 'Enter the number that represents the percentage of parallax move.', 'archicon-core' ),
					'dependency' => array(
						'show' => array(
							'custom_parallax' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'archicon_core_single_svg', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['parallax_data']  = $this->get_parallax_data( $atts );

			return archicon_core_get_template_part( 'shortcodes/single-svg', 'variations/' . $atts['layout'] . '/templates/' . $atts['layout'], '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-single-svg';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['custom_parallax'] ) && ( 'yes' === $atts['custom_parallax'] ) ? 'qodef-custom-parallax' : '';
			$holder_classes[] = ! empty( $atts['appear'] ) && ( 'yes' === $atts['appear'] ) ? 'qodef-has-appear' : '';

			return implode( ' ', $holder_classes );
		}

		private function get_parallax_data( $atts ) {
			$data = array();

			if ( ! empty( $atts['parallax_amount'] ) ) {
				$data[] = $atts['parallax_amount'];
			}

			return $data;
		}
	}
}
