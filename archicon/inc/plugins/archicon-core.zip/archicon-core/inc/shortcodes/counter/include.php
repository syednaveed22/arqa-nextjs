<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/counter/class-archiconcore-counter-shortcode.php';

foreach ( glob( ARCHICON_CORE_SHORTCODES_PATH . '/counter/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
