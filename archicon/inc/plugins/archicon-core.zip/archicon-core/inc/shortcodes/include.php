<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/helper.php';
include_once ARCHICON_CORE_SHORTCODES_PATH . '/class-archiconcore-shortcodes.php';
