<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/highlight/class-archiconcore-highlight-shortcode.php';
