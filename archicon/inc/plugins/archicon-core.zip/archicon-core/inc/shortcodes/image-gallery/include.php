<?php

include_once ARCHICON_CORE_SHORTCODES_PATH . '/image-gallery/class-archiconcore-image-gallery-shortcode.php';
