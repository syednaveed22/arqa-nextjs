<?php

include_once ARCHICON_CORE_INC_PATH . '/search/class-archiconcore-search.php';
include_once ARCHICON_CORE_INC_PATH . '/search/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/search/dashboard/admin/search-options.php';

foreach ( glob( ARCHICON_CORE_INC_PATH . '/search/layouts/*/include.php' ) as $layout ) {
	include_once $layout;
}
