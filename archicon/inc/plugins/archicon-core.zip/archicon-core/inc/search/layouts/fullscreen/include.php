<?php

include_once ARCHICON_CORE_INC_PATH . '/search/layouts/fullscreen/helper.php';
include_once ARCHICON_CORE_INC_PATH . '/search/layouts/fullscreen/class-archiconcore-fullscreen-search.php';
