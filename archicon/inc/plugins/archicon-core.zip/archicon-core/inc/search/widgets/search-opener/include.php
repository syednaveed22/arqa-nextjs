<?php

include_once ARCHICON_CORE_INC_PATH . '/search/widgets/search-opener/class-archiconcore-search-opener.php';
