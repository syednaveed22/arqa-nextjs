<?php

archicon_core_get_opener_icon_html(
	array(
		'option_name'  => 'mobile_menu',
		'custom_class' => 'qodef-mobile-header-opener',
	),
	true
);
