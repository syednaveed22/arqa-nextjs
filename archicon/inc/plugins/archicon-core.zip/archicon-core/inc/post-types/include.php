<?php

include_once ARCHICON_CORE_CPT_PATH . '/class-archiconcore-custom-post-types.php';
