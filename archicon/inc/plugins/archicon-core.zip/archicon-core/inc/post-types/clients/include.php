<?php

include_once ARCHICON_CORE_CPT_PATH . '/clients/helper.php';

foreach ( glob( ARCHICON_CORE_CPT_PATH . '/clients/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}
