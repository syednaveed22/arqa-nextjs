<?php

include_once ARCHICON_CORE_INC_PATH . '/content/helper.php';
