<?php

if ( ! function_exists( 'archicon_core_add_archicon_spinner_layout_option' ) ) {
	/**
	 * Function that set new value into page spinner layout options map
	 *
	 * @param array $layouts - module layouts
	 *
	 * @return array
	 */
	function archicon_core_add_archicon_spinner_layout_option( $layouts ) {
		$layouts['archicon'] = esc_html__( 'Archicon', 'archicon-core' );

		return $layouts;
	}

	add_filter( 'archicon_core_filter_page_spinner_layout_options', 'archicon_core_add_archicon_spinner_layout_option' );
}

if ( ! function_exists( 'archicon_core_set_archicon_spinner_layout_as_default_option' ) ) {
	/**
	 * Function that set default value for page spinner layout options map
	 *
	 * @param string $default_value
	 *
	 * @return string
	 */
	function archicon_core_set_archicon_spinner_layout_as_default_option( $default_value ) {
		return 'archicon';
	}

	add_filter( 'archicon_core_filter_page_spinner_default_layout_option', 'archicon_core_set_archicon_spinner_layout_as_default_option' );
}
