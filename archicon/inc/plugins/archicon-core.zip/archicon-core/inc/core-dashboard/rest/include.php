<?php

include_once ARCHICON_CORE_INC_PATH . '/core-dashboard/rest/class-archiconcore-dashboard-rest-api.php';
