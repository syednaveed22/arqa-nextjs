<?php

include_once ARCHICON_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-archiconcore-dashboard-system-info-page.php';
