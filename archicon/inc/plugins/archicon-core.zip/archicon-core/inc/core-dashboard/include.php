<?php

include_once ARCHICON_CORE_INC_PATH . '/core-dashboard/class-archiconcore-dashboard.php';
